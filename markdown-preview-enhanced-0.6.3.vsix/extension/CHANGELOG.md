Please go check the [project releases page](https://github.com/shd101wyy/vscode-markdown-preview-enhanced).
