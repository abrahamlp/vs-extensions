module.exports = {
  arrowParens: "always",
  endOfLine: "lf",
  quoteProps: "consistent",
  trailingComma: "all",
};
